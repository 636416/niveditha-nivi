# Responsive Airpods Landing Page
## [Watch it on youtube](https://youtu.be/4YR6goNFeSY)
### Responsive Airpods Landing Page

- Responsive Airpods Landing Page Using HTML CSS & JavaScript
- Contains animations with gsap.
- Contains animations when scrolling.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
